
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'salmanetamo',
  applicationName: 'personal-diary-app',
  appUid: 'XqDYpcnsSL3tWc6cYZ',
  orgUid: 'b30f89bb-aef9-4586-b9ee-ea738d2f0362',
  deploymentUid: '0828608b-7d79-4a6d-a7c4-b9490f369414',
  serviceName: 'personal-diary-app-backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'personal-diary-app-backend-dev-CreateDiaryEntry', timeout: 6 };

try {
  const userHandler = require('./src/functions/create-diary-entry/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}